/**
 * Interface Penghijauan
 *
 * @author Bryan Oliver
 * @version 24.4.2021
 */

public interface Penghijauan {

    public void fotosintesis();
    public void rontokDaun();
    public void tumbuhDaun();
}
