/**
 * Interface Komoditas
 *
 * @author Bryan Oliver
 * @version 24.4.2021
 */

public interface Komoditas {
    
    public void setHarga(int price);
    public int getHarga();
}
