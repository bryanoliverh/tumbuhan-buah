/**
 * Class Tumbuhan
 *
 * @author Bryan Oliver
 * @version 24.4.2021
 */
public abstract class Tumbuhan {
    
    public int lenght = 50;

    public void tumbuh()
    {
        lenght += 5;
    }
}
