
/**
 * Class BuahMangga
 *
 * @author Bryan Oliver
 * @version 24.4.2021
 */
public class BuahMangga extends Buah 
{
    public BuahMangga(int age)
    {
        super(age);
    }
}
