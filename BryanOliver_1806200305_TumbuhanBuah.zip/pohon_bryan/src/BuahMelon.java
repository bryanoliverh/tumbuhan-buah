/**
 * Class BuahPepaya
 *
 * @author Bryan Oliver
 * @version 24.4.2021
 */
public class BuahMelon extends Buah
{
    public BuahMelon(int age)
    {
        super(age);
    }
}
